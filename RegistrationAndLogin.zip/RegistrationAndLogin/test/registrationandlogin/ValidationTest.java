/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package registrationandlogin;


import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author MP
 */
public class ValidationTest {
    

    @Test
    public void testValidUsername() {
        assertTrue(Validation.isValidUsername("Nkosin"));
        assertFalse(Validation.isValidUsername("abc")); // too short
    }

    @Test
    public void testValidPassword() {
        assertTrue(Validation.isValidPassword("Passw0rd!"));
    }

    @Test
    public void testInvalidPasswordTooShort() {
        assertFalse(Validation.isValidPassword("Ab1!"));
    }

    @Test
    public void testInvalidPasswordNoUppercase() {
        assertFalse(Validation.isValidPassword("password1!"));
    }

    @Test
    public void testInvalidPasswordNoDigit() {
        assertFalse(Validation.isValidPassword("Password!"));
    }

    @Test
    public void testInvalidPasswordNoSpecialChar() {
        assertFalse(Validation.isValidPassword("Password1"));
    }
}