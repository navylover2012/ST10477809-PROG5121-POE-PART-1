/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registrationandlogin;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

//This is my custom rounded field
class RoundedTextField extends JTextField {
    private int arc;

    public RoundedTextField(int columns, int arc) {
        super(columns);
        this.arc = arc;
        setOpaque(false); //Made it transparent so i can paint it 
        setBorder(new EmptyBorder(5, 10, 5, 10));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // A white background with a shadow 
        g2.setColor(Color.BLACK);
        g2.fillRoundRect(2, 2, getWidth() - 2, getHeight() - 2, arc, arc);

        g2.setColor(Color.WHITE);
        g2.fillRoundRect(0, 0, getWidth() - 4, getHeight() - 4, arc, arc);

        super.paintComponent(g);
        g2.dispose();
    }
}

class RoundedPasswordField extends JPasswordField {
    private int arc;

    public RoundedPasswordField(int columns, int arc) {
        super(columns);
        this.arc = arc;
        setOpaque(false);
        setBorder(new EmptyBorder(5, 10, 5, 10));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(Color.BLACK);
        g2.fillRoundRect(2, 2, getWidth() - 2, getHeight() - 2, arc, arc);

        g2.setColor(Color.WHITE);
        g2.fillRoundRect(0, 0, getWidth() - 4, getHeight() - 4, arc, arc);

        super.paintComponent(g);
        g2.dispose();
    }
}

//This is the Registration form
class RegistrationForm extends JFrame implements ActionListener {
    JLabel lblUser, lblPass, lblCell, lblEmail;
    RoundedTextField txtUser, txtCell, txtEmail;
    RoundedPasswordField txtPass;
    JButton btnSubmit, btnClear;

    static String registeredUser = "";
    static String registeredPass = "";

    public RegistrationForm() {
        setTitle("Registration Form");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBackground(new Color(128, 0, 128)); // purple background
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        lblUser = new JLabel("Username:", JLabel.RIGHT);
        lblUser.setForeground(Color.WHITE);
        txtUser = new RoundedTextField(15, 20);

        lblPass = new JLabel("Password:", JLabel.RIGHT);
        lblPass.setForeground(Color.WHITE);
        txtPass = new RoundedPasswordField(15, 20);

        lblCell = new JLabel("Cell Number:", JLabel.RIGHT);
        lblCell.setForeground(Color.WHITE);
        txtCell = new RoundedTextField(15, 20);

        lblEmail = new JLabel("Email:", JLabel.RIGHT);
        lblEmail.setForeground(Color.WHITE);
        txtEmail = new RoundedTextField(15, 20);

        btnSubmit = new JButton("Register");
        btnClear = new JButton("Clear");

        btnSubmit.addActionListener(this);
        btnClear.addActionListener(this);

        panel.add(lblUser); panel.add(txtUser);
        panel.add(lblPass); panel.add(txtPass);
        panel.add(lblCell); panel.add(txtCell);
        panel.add(lblEmail); panel.add(txtEmail);
        panel.add(btnSubmit); panel.add(btnClear);

        add(panel);
        setVisible(true);
    }

  
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSubmit) {
            String user = txtUser.getText();
            String pass = new String(txtPass.getPassword());

           if (!Validation.isValidUsername(user)) {
    JOptionPane.showMessageDialog(this, "Username must be at least 5 characters long.");
    return;
}
if (!Validation.isValidPassword(pass)) {
    JOptionPane.showMessageDialog(this,
        "Password must have 8+ chars, upper, lower, digit, special.");
    return;
}
            registeredUser = user;
            registeredPass = pass;

            JOptionPane.showMessageDialog(this, "Registration Successful!\nProceed to Login.");
            dispose();
            new LoginForm();
        } else {
            txtUser.setText("");
            txtPass.setText("");
            txtCell.setText("");
            txtEmail.setText("");
        }
    }
}

//This is the Login Form
class LoginForm extends JFrame implements ActionListener {
    JLabel lblUser, lblPass;
    RoundedTextField txtUser;
    RoundedPasswordField txtPass;
    JButton btnLogin, btnClear;

    public LoginForm() {
        setTitle("Login Form");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBackground(new Color(128, 0, 128));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        lblUser = new JLabel("Username:", JLabel.RIGHT);
        lblUser.setForeground(Color.WHITE);
        txtUser = new RoundedTextField(15, 20);

        lblPass = new JLabel("Password:", JLabel.RIGHT);
        lblPass.setForeground(Color.WHITE);
        txtPass = new RoundedPasswordField(15, 20);

        btnLogin = new JButton("Login");
        btnClear = new JButton("Clear");
        btnLogin.addActionListener(this);
        btnClear.addActionListener(this);

        panel.add(lblUser); panel.add(txtUser);
        panel.add(lblPass); panel.add(txtPass);
        panel.add(btnLogin); panel.add(btnClear);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnLogin) {
            String user = txtUser.getText();
            String pass = new String(txtPass.getPassword());

            if (user.equals(RegistrationForm.registeredUser) &&
                pass.equals(RegistrationForm.registeredPass)) {
                JOptionPane.showMessageDialog(this, "Welcome, " + user + "!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password!");
            }
        } else {
            txtUser.setText("");
            txtPass.setText("");
        }
    }
}

//This is my main app
public class RegistrationAndLogin {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegistrationForm());
    }
}
